"""
ASSIGNMENT 2
GROUP NAME: DAN/EXT 22
GROUP MEMBER:
Nguyen Duy Quang Lai        -   s389980
Angel Chang                 -   s377501
Nicole Suzanne Sattler      -   s195029
Youssef Elkassaby           -   s392402
============================================================================
Question 2
Create a program that analyses temperature data collected from multiple weather
stations in Australia. The data is stored in multiple CSV files under a "temperatures"
folder, with each file representing data from one year. Process ALL .csv files in the
temperatures folder. Ignore missing temperature values (NaN) in calculations.
"""

import csv
import glob
import os
import math


def is_valid_temp(value: str) -> bool:
    """Return True if value is a usable temperature (not blank/NaN and convertible to float)."""
    if value is None:
        return False

    s = str(value).strip()
    if s == "":
        return False

    if s.lower() in ["nan", "null", "none", "na", "n/a"]:
        return False

    try:
        float(s)
        return True
    except ValueError:
        return False


def population_stddev(values):
    """
    Compute population standard deviation (divide by N).
    Returns 0.0 if fewer than 2 values (no variation).
    """
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    variance = sum((x - mean) ** 2 for x in values) / n
    return math.sqrt(variance)


def analyze_weather_data():
    folder_path = "temperatures"
    file_pattern = os.path.join(folder_path, "*.csv")
    csv_files = glob.glob(file_pattern)

    if not csv_files:
        print("Error: No CSV files found in the temperatures folder.")
        return

    seasons_map = {
        "Summer": ["December", "January", "February"],
        "Autumn": ["March", "April", "May"],
        "Winter": ["June", "July", "August"],
        "Spring": ["September", "October", "November"],
    }

    # Collect temps across all years/stations for seasonal averages
    season_temps = {season: [] for season in seasons_map}

    # Collect temps across all years for each station
    station_data = {}

    for filename in csv_files:
        with open(filename, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)

            # Strip whitespace in header names (safe for messy CSVs)
            if reader.fieldnames:
                reader.fieldnames = [name.strip() for name in reader.fieldnames]

            # Station column detection (prefer STATION_NAME)
            station_col = None
            for h in (reader.fieldnames or []):
                if h and h.strip().upper() == "STATION_NAME":
                    station_col = h
                    break
            if station_col is None:
                for h in (reader.fieldnames or []):
                    if h and "station" in h.lower():
                        station_col = h
                        break

            if station_col is None:
                continue  # can't identify stations, skip file

            for row in reader:
                station_name = row.get(station_col)
                if not station_name:
                    continue

                station_name = station_name.strip()
                if station_name not in station_data:
                    station_data[station_name] = []

                # Month columns are the 12 months (as per dataset)
                for season, months in seasons_map.items():
                    for month in months:
                        temp_str = row.get(month)
                        if is_valid_temp(temp_str):
                            temp = float(temp_str)
                            season_temps[season].append(temp)
                            station_data[station_name].append(temp)

    # ----- TASK 1: SEASONAL AVERAGES -----
    with open("average_temp.txt", "w", encoding="utf-8") as f:
        for season in ["Summer", "Autumn", "Winter", "Spring"]:
            temps = season_temps[season]
            if temps:
                avg = sum(temps) / len(temps)
                f.write(f"{season}: {avg:.1f}°C\n")
            else:
                f.write(f"{season}: 0.0°C\n")

    print("Generated: average_temp.txt")

    # Prepare station stats
    station_stats = []
    for station, temps in station_data.items():
        if temps:
            maximum = max(temps)
            minimum = min(temps)
            temp_range = maximum - minimum
            std_dev = population_stddev(temps)

            station_stats.append(
                {"name": station, "range": temp_range, "max": maximum, "min": minimum, "std": std_dev}
            )

    if not station_stats:
        print("Error: No valid station temperature data found.")
        return

    # ----- TASK 2: LARGEST TEMPERATURE RANGE -----
    max_range = max(s["range"] for s in station_stats)
    tol = 0.01

    with open("largest_temp_range_station.txt", "w", encoding="utf-8") as f:
        for s in station_stats:
            if abs(s["range"] - max_range) < tol:
                f.write(
                    f"{s['name']}: Range {s['range']:.1f}°C "
                    f"(Max: {s['max']:.1f}°C, Min: {s['min']:.1f}°C)\n"
                )
    print("Generated: largest_temp_range_station.txt")

    # ----- TASK 3: TEMPERATURE STABILITY -----
    min_std = min(s["std"] for s in station_stats)
    max_std = max(s["std"] for s in station_stats)

    with open("temperature_stability_stations.txt", "w", encoding="utf-8") as f:
        for s in station_stats:
            if abs(s["std"] - min_std) < tol:
                f.write(f"Most Stable: {s['name']}: StdDev {s['std']:.1f}°C\n")
        for s in station_stats:
            if abs(s["std"] - max_std) < tol:
                f.write(f"Most Variable: {s['name']}: StdDev {s['std']:.1f}°C\n")

    print("Generated: temperature_stability_stations.txt")
    print("--- Analysis Complete ---")

if __name__ == "__main__":
    analyze_weather_data()
